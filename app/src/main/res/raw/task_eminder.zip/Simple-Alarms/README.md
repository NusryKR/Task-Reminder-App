# Simple-Alarms

<img src="https://raw.githubusercontent.com/PPartisan/Simple-Alarms/master/images/Screenshot_1483542026.png" data-canonical-src="https://raw.githubusercontent.com/PPartisan/Simple-Alarms/master/images/Screenshot_1483542026.png" width="250" /> <img src="https://raw.githubusercontent.com/PPartisan/Simple-Alarms/master/images/Screenshot_1483542049.png" data-canonical-src="https://raw.githubusercontent.com/PPartisan/Simple-Alarms/master/images/Screenshot_1483542049.png" width="250" />

This a straightforward alarm app for Android with the following features:

* Store multiple alarms
* Set indvidual days the alarm should repeat
* Mute an alarm by removing all days
* Shows notification with vibration and a noise when alarm sounds

Anyone is welcome to use this source code in their own app ([MIT Licence](https://github.com/PPartisan/Simple-Alarms/blob/master/LICENCE)). Attribution would be appreciated though! Thanks.
